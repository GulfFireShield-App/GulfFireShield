package com.gulffireshieldtrading.app
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
class MainActivity : AppCompatActivity() {
 private val products=listOf("Steel Pipes","Threaded Fittings","Grooved Fittings","Buttweld Fittings","Forged Flanges","Valves","Zone Control Valve Assemblies","High-Pressure Steel Fittings","Pipe Clamps & Threaded Rods","Fire Protection Accessories","Hardware & Safety Products")
 override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_main);val c=findViewById<LinearLayout>(R.id.productsContainer);products.forEachIndexed{i,n->val t=TextView(this);t.text="%02d  %s".format(i+1,n);t.textSize=17f;t.setTextColor(getColor(R.color.text));t.setPadding(20,22,20,22);t.setBackgroundColor(getColor(R.color.card));val p=LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,10);c.addView(t,p)};findViewById<Button>(R.id.whatsappButton).setOnClickListener{startActivity(Intent(Intent.ACTION_VIEW,Uri.parse("https://wa.me/971544462358")))};findViewById<TextView>(R.id.productsTab).setOnClickListener{findViewById<ScrollView>(R.id.scroll).smoothScrollTo(0,c.top)};findViewById<TextView>(R.id.contactTab).setOnClickListener{findViewById<ScrollView>(R.id.scroll).fullScroll(View.FOCUS_DOWN)};findViewById<TextView>(R.id.homeTab).setOnClickListener{findViewById<ScrollView>(R.id.scroll).smoothScrollTo(0,0)}}}
